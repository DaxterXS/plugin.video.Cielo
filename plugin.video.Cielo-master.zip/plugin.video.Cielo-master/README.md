# Diretta SkyTG24 Kodi plugin

Kodi unofficial plugin to stream Sky Tg24 from the official website.

## Installation

Download the contents of the repository as a zip file and then from the add-ons menu select "Install from zip file"